#
# Copyright (c) 2022 Airbyte, Inc., all rights reserved.
#

from airbyte_cdk.sources.declarative.datetime.min_max_datetime import MinMaxDatetime

__all__ = ["MinMaxDatetime"]
